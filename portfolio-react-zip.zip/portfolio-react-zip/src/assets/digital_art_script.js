$(function () {
	let imgPath = [
		"/assets/image/divine-noise-fractal.png",
		"/assets/image/chaos-flower-fractal.png",
		"/assets/image/turquoise-cymbals-fractal.png",
		"/assets/image/yellow-feng-shui-fractal.png",
		"/assets/image/cellular-origins-fractal.png",
		"/assets/image/astro-observer-fractal.png",
		"/assets/image/blue-emergence-fractal.png",
		"/assets/image/pink-orb-fractal.png",
		"/assets/image/illustrious-magician-fractal.png",
		"/assets/image/burst-fractal.png",
		"/assets/image/puzzled-fire-fractal.png",
		"/assets/image/spiral-chaos-fractal.png",
		"/assets/image/jade-phoenix-fractal.png",
		"/assets/image/resonant-fireworks-fractal.png",
		"/assets/image/vortex-light-fractal.png",
		"/assets/image/emerald-jade-fractal.png",
		"/assets/image/lava-inferno-fractal.png",
		"/assets/image/bleeding-star-fractal.png",
		"/assets/image/blue-rose-fractal.png",
		"/assets/image/neural-network-fractal.png",
		"/assets/image/curious-amoeba-fractal.png",
		"/assets/image/morning-eagle-fractal.png",
		"/assets/image/blue-vortex-fractal.png",
		"/assets/image/eye-burst-fractal.png",
		"/assets/image/artery-fractal.png",
		"/assets/image/phoenix-fractal.png",
		"/assets/image/neutron-fractal.png",
		"/assets/image/chrysalis-flower-fractal.png",
		"/assets/image/icy-mint-fractal.png",
		"/assets/image/worlds-fractal.png",
		"/assets/image/rose-fractal.png",
		"/assets/image/disco-spiral-fractal.png",
		"/assets/image/blue-velvet-fractal.png",
		"/assets/image/neuron-fractal.png",
		"/assets/image/poseidon-fractal.png",
		"/assets/image/golden-phoenix-fractal.png",
		"/assets/image/color-wheel-fractal.png",
		"/assets/image/sun-rose-fractal.png",
		"/assets/image/starlight-butterfly-fractal.png",
		"/assets/image/icicle-lights-fractal.png",
		"/assets/image/space-rubiks-fractal.png",
		"/assets/image/philosopher-fractal.png",
		"/assets/image/nebulous-planet-fractal.png",
		"/assets/image/lost-heart-fractal.png",
		"/assets/image/magma-jellyfish-fractal.png",
		"/assets/image/emerald-matrix-fractal.png",
		"/assets/image/vitruvian-flower-fractal.png",
		"/assets/image/autograph-fractal.png",
		"/assets/image/valentines-vortex-fractal.png",
		"/assets/image/glowing-orbit-fractal.png",
		"/assets/image/rainbow-coral-fractal.png",
		"/assets/image/electric-phoenix-fractal.png",
		"/assets/image/beating-heart-fractal.png",
		"/assets/image/rose-pendant-fractal.png",
		"/assets/image/exotic-silk-fractal.png",
		"/assets/image/bone-fracture-fractal.png",
		"/assets/image/dark-matter-fractal.png",
		"/assets/image/emerging-flame-fractal.png",
		"/assets/image/perfect-rose-fractal.png",
		"/assets/image/broken-phoenix-fractal.png",
		"/assets/image/blue-sprite-fractal.png",
		"/assets/image/infinite-coral-fractal.png",
		"/assets/image/window-sprite-fractal.png",
		"/assets/image/matrix-coin-fractal.png",
		"/assets/image/lava-drip-fractal.png",
		"/assets/image/infinite-circle-fractal.png",
	]

	imgPath.forEach((imgUrl) => {
		let imgDiv = $("<div class='img-w'></div>")
		imgDiv.appendTo($(".gallery"))
		imgUrl = imgUrl.replace(".png", "-min.png")
		imgDiv.css("background-image", "url(.." + imgUrl + ")")

		imgDiv.wrap("<div class='img-c'></div>")
	})

	$(".img-c").on("click", function () {
		let w = $(this).outerWidth()
		let h = $(this).outerHeight()

		$(".active").not($(this)).remove()
		let copy = $(this).clone()
		copy.insertAfter($(this))
			.height(h)
			.width(w)
			.delay(500)
			.addClass("active")
		copy.addClass("positioned")
		copy.wrap("<div class='backdrop'></div>")
	})
})

$(document).on("click", ".img-c.active, .backdrop", function () {
	$(this).remove()
	$(".backdrop").remove()
})
